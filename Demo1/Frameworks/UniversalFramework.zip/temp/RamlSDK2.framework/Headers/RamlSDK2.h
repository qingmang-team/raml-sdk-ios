//
//  RamlSDK2.h
//  RamlSDK2
//
//  Created by ChenHeng on 11/08/2017.
//  Copyright © 2017 qingmang. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for RamlSDK2.
FOUNDATION_EXPORT double RamlSDK2VersionNumber;

//! Project version string for RamlSDK2.
FOUNDATION_EXPORT const unsigned char RamlSDK2VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RamlSDK2/PublicHeader.h>


